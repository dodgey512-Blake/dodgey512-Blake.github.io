// Test-only page CDP client. Uses the running debug WebView, not a desktop browser render.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const targets=await (await fetch('http://127.0.0.1:9223/json/list')).json();
const target=targets.find(t=>t.url.startsWith('https://appassets.androidplatform.net/weather-v1/'));
if(!target)throw Error('No trusted Weather WebView target');
const ws=new WebSocket(target.webSocketDebuggerUrl);const requests=new Map();let id=0;
await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
ws.addEventListener('message',event=>{const data=JSON.parse(event.data);const entry=requests.get(data.id);if(entry){requests.delete(data.id);clearTimeout(entry.timer);data.error?entry.reject(Error(data.error.message)):entry.resolve(data.result);}});
const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;const timer=setTimeout(()=>{requests.delete(n);reject(Error('CDP timeout: '+method));},30000);requests.set(n,{resolve,reject,timer});ws.send(JSON.stringify({id:n,method,params}));});
const evaluate=async expression=>{const response=await call('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(response.exceptionDetails)throw Error(JSON.stringify(response.exceptionDetails));return response.result.value;};
const pause=ms=>new Promise(r=>setTimeout(r,ms));
const click=label=>evaluate(`(()=>{const b=[...document.querySelectorAll('button')].find(e=>e.textContent.trim()===${JSON.stringify(label)});if(!b)throw Error('Missing button: '+${JSON.stringify(label)});b.click();return true})()`);
const screenshot=async name=>{await pause(800);const image=await call('Page.captureScreenshot',{format:'png'});await fs.writeFile(path.join(root,'acceptance','webview-'+name+'.png'),Buffer.from(image.data,'base64'));await fs.writeFile(path.join(root,'acceptance','android-'+name+'.png'),execFileSync('/Users/Baike_1/Library/Android/sdk/platform-tools/adb',['-s','emulator-5556','exec-out','screencap','-p']));};
try{
  const text=await evaluate('document.body.innerText');
  if(text.includes('先看看 Austin 的天气')){await click('先看看 Austin 的天气');await pause(15000);}
  if((await evaluate('location.hash')).includes('/settings'))await click('天气');
  await screenshot('home-zh');
  await click('设置');await screenshot('settings-zh');
  await click('English');await screenshot('settings-en');
  const english=await evaluate("({language:document.documentElement.lang,settings:document.body.innerText.includes('Settings'),bridge:Object.isFrozen(WeatherNative),url:location.href})");
  await click('简体中文');await pause(500);
  await fs.writeFile(path.join(root,'acceptance','ui-language-verification.json'),JSON.stringify({source:'Actual Android API36 WebView page CDP',english,restoredLanguage:await evaluate('document.documentElement.lang')},null,2));
  console.log(JSON.stringify({captured:['home-zh','settings-zh','settings-en'],english,restoredLanguage:await evaluate('document.documentElement.lang')}));
}finally{ws.close();}
