#!/bin/sh
set -eu
WEATHER_ANDROID_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$WEATHER_ANDROID_ROOT"
if [ -z "${ANDROID_HOME:-}" ] && [ -d "$HOME/Library/Android/sdk" ]; then
  ANDROID_HOME="$HOME/Library/Android/sdk"
  export ANDROID_HOME
fi
node scripts/package-web.mjs "${1:-../../demo/V1.0-双语天气MVP/out}"
./gradlew :app:assembleDebug :app:assembleDebugAndroidTest :app:lintDebug --console=plain
python3 scripts/verify-apk-assets.py
mkdir -p dist
cp app/build/outputs/apk/debug/app-debug.apk dist/Weather-V1.0-debug.apk
cp app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk dist/Weather-V1.0-tests.apk
python3 scripts/archive-source.py
shasum -a 256 dist/Weather-V1.0-debug.apk dist/Weather-V1.0-tests.apk dist/Weather-V1.0-AndroidStudio.zip > dist/SHA256SUMS.txt
