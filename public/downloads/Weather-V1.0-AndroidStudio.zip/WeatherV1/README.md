# 天气 Weather · Android V1.0

这是天气产品的 Android Hybrid 宿主。使用 AndroidX WebViewAssetLoader 把静态界面从安装包中的资产目录加载到 `https://appassets.androidplatform.net/weather-v1/`，天气与地点接口通过 HTTPS 获取。界面可以离线启动；没有可用天气数据时由产品的数据不足状态处理。

## Android Studio 使用

1. 在 Android Studio 打开本目录，Gradle Sync 使用 JDK 17 或更高版本；本机已验证的 JBR 路径为 `/Applications/Android Studio.app/Contents/jbr/Contents/Home`。
2. 安装 Android SDK 37，选择模拟器或 Android 8.0 以上设备，运行 `app`。
3. 工程版本为 Gradle 9.3.1、AGP 9.1.1、AndroidX WebKit 1.18.0，minSdk 26、targetSdk 37、compileSdk 37。

本机API37模拟器若出现启动后ADB命令无响应，可以用`sh scripts/start-emulator.sh`冷启动软件渲染，或在Android Studio设备设置中选择Software。此次宿主OpenGL仅提供GLES3.0，API37要求GLES3.1；验收使用SwiftShader，不能用模拟器帧率代表真机性能。

## 更新 Web 包并构建

```bash
node scripts/package-web.mjs ../../demo/V1.0-双语天气MVP/out
./gradlew :app:assembleDebug :app:assembleDebugAndroidTest :app:lintDebug
```

Web 构建必须使用 `/weather-v1` basePath。打包脚本会验证入口并记录 SHA-256。APK 位于 `app/build/outputs/apk/debug/app-debug.apk`；对外交付文件复制到 `dist/`。

工程已配置AAPT保留`_next`目录。不能恢复Android默认的下划线目录忽略规则，否则Next的JS/CSS会被漏装，界面只剩未激活的静态内容。

执行 `sh scripts/build-and-export.sh` 可一次完成打包、构建、Lint、生成APK和Android Studio工程压缩包，并输出SHA-256清单。压缩包包含离线Web资产，不包含本地SDK路径、构建缓存或签名私钥。

运行中的模拟器上可执行 `python3 scripts/verify-native.py --fresh`。`--fresh`仅清除本应用的验收数据，以验证中文默认值；仪器测试与截图保存在`acceptance/`，不会清除其他应用。

## 原生接口

产品页可以调用 `window.WeatherNative`：

1. `requestNotifications()`：由设置内用户操作触发通知授权，回传 `{type:'notifications',granted}`。
2. `notify(title,body)`：已授权时发布真实 Android 通知，回传 `{type:'notification',delivered:true}`。
3. `requestLocation()`：在用户主动定位时申请位置权限并读取坐标，回传 `{type:'location',latitude,longitude,accuracy}`。
4. `saveFile(name,mime,base64)`：使用系统“保存到”窗口导出 JSON、ICS 或文本；用户完成保存后才回传 `{type:'saved',name}`。
5. `setLanguage('zh-CN'|'en')`：让原生反馈使用相同语言。

回传统一通过 `window.addEventListener('weather-native', event => event.detail)`；失败为 `{type:'error',operation,message}`，取消保存为 `saveCancelled`。桥由主帧、精确本地来源与当前文档路径共同限制，外链在浏览器打开，跨站内容不会获得桥。

Android 返回键优先调用 `window.__weatherBack()`，产品处理返回后应返回 `true`；根页面返回 `false`，宿主使用 WebView 历史或退出。应用回到前台发送 `weather-resume`，产品可据此刷新天气。

## 边界

1. 原生通知是可用接口，不等于服务器推送或后台持续天气监测；本工程没有声明这些能力已经实现。
2. 桌面浏览器、Android 模拟器和物理设备是不同验收层级；模拟器结果不替代真机性能、TalkBack、厂商后台策略验收。
3. 该包是开发验收 APK，未使用正式签名或上传商店。

官方实现依据：[本地网页内容](https://developer.android.com/develop/ui/views/layout/webapps/load-local-content)、[原生桥来源限制](https://developer.android.com/privacy-and-security/risks/insecure-webview-native-bridges)。
