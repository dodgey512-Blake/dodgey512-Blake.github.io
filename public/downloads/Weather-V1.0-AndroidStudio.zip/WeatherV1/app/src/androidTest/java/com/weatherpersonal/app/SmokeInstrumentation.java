package com.weatherpersonal.app;

import android.app.Instrumentation;
import android.content.Intent;
import android.os.Bundle;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;

/** Exercises the packaged WebView on Android, separately from browser-only checks. */
public final class SmokeInstrumentation extends Instrumentation {
    private MainActivity activity;
    private int count;
    private String evaluate(String script) throws Exception {
        CountDownLatch latch=new CountDownLatch(1);
        String[] value={"null"};
        runOnMainSync(()->activity.webViewForTest().evaluateJavascript(script,result->{value[0]=result;latch.countDown();}));
        if(!latch.await(15,TimeUnit.SECONDS))throw new AssertionError("JavaScript response timed out");
        return value[0];
    }
    private void check(String name,String expression) throws Exception {
        if(!"true".equals(evaluate(expression)))throw new AssertionError(name);
        count++;
        Bundle status=new Bundle();status.putString("stream","PASS "+name+"\n");sendStatus(0,status);
    }
    @Override public void onCreate(Bundle args){super.onCreate(args);start();}
    @Override public void onStart(){
        Bundle result=new Bundle();
        try{
            Intent launch=new Intent(getTargetContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity=(MainActivity)startActivitySync(launch);
            waitForIdleSync();
            long deadline=System.currentTimeMillis()+60000;
            boolean ready=false;
            while(System.currentTimeMillis()<deadline && !ready) {
                try { ready="true".equals(evaluate("document.readyState==='complete' && !!window.WeatherNative && document.body.innerText.length>30")); }
                catch(AssertionError initializing) { /* The first WebView renderer can still be initializing on a cold emulator. */ }
                if(!ready)Thread.sleep(250);
            }
            if(!ready)throw new AssertionError("Packaged UI did not become ready within 60 seconds");
            check("trusted HTTPS local origin","location.origin==='https://appassets.androidplatform.net'");
            check("versioned local assets","location.pathname.startsWith('/weather-v1/')");
            check("packaged UI rendered","document.body.innerText.length>30 && !document.body.innerText.includes('ERR_') && document.querySelectorAll('button').length>0");
            check("native facade available","typeof WeatherNative.requestNotifications==='function' && typeof WeatherNative.requestLocation==='function' && typeof WeatherNative.saveFile==='function'");
            check("native facade immutable","Object.isFrozen(WeatherNative)");
            check("local storage available","(()=>{localStorage.setItem('__native_smoke','ok');const ok=localStorage.getItem('__native_smoke')==='ok';localStorage.removeItem('__native_smoke');return ok})()");
            check("Chinese default document language","document.documentElement.lang.startsWith('zh')");
            check("local script assets requested","performance.getEntriesByType('resource').filter(x=>x.initiatorType==='script' && x.name.startsWith(location.origin)).length>0");
            result.putString("stream","Weather native smoke: "+count+" checks passed.\n");
            result.putInt("checks",count);finish(ActivityResult.OK,result);
        }catch(Throwable error){result.putString("stream","FAIL "+error+"\n");finish(ActivityResult.FAIL,result);}
    }
    private static final class ActivityResult{static final int OK=-1;static final int FAIL=0;}
}
