package com.weatherpersonal.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;

/** Offline-first hybrid host. No remote document is loaded into the native bridge origin. */
public final class MainActivity extends Activity {
    public static final String ORIGIN = "https://appassets.androidplatform.net";
    public static final String START = ORIGIN + "/weather-v1/";
    private static final int LOCATION_PERMISSION = 101;
    private static final int NOTIFICATION_PERMISSION = 102;
    private static final int SAVE_DOCUMENT = 103;
    private static final int PICK_DOCUMENT = 104;
    private static final String CHANNEL = "weather_updates_v1";
    private static final Set<String> API_HOSTS = new HashSet<>(Arrays.asList("api.weather.gov", "api.open-meteo.com", "air-quality-api.open-meteo.com", "geocoding-api.open-meteo.com"));
    private WebView web;
    private String language;
    private boolean requestInProgress;
    private byte[] pendingFile;
    private String pendingName;
    private ValueCallback<Uri[]> filePicker;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;
    private CancellationSignal locationCancellation;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private static final String BRIDGE = "(()=>{if(window.WeatherNative)return;const send=(method,args={})=>window.WeatherBridge.postMessage(JSON.stringify({method,...args}));Object.defineProperty(window,'WeatherNative',{value:Object.freeze({isNative:true,version:'1.0.0',requestNotifications:()=>send('requestNotifications'),notify:(title,body)=>send('notify',{title,body}),requestLocation:()=>send('requestLocation'),saveFile:(name,mime,base64)=>send('saveFile',{name,mime,base64}),setLanguage:(language)=>send('setLanguage',{language})}),writable:false});window.dispatchEvent(new CustomEvent('weather-native',{detail:{type:'ready',version:'1.0.0'}}));})();";

    // React needs JavaScript; only the bundled, frame-isolated origin receives the bridge.
    @SuppressLint("SetJavaScriptEnabled") @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        language = getPreferences(MODE_PRIVATE).getString("language", "zh-CN");
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(9,16,25));
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            getWindow().getDecorView().setSystemUiVisibility(0);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                android.graphics.Insets ime = insets.getInsets(WindowInsets.Type.ime());
                v.setPadding(bars.left,bars.top,bars.right,Math.max(bars.bottom,ime.bottom));
            } else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(9,16,25));
        root.addView(web,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        web.setId(View.generateViewId());
        web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setGeolocationEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setTextZoom(Math.max(100,Math.round(getResources().getConfiguration().fontScale*100)));
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if ("https".equals(url.getScheme()) && "appassets.androidplatform.net".equals(url.getHost())) {
                    Uri assetUri = url;
                    if (url.getPath() != null && url.getPath().endsWith("/")) assetUri = url.buildUpon().path(url.getPath()+"index.html").build();
                    WebResourceResponse response = loader.shouldInterceptRequest(assetUri);
                    if (response == null) return denied(404,"Asset not found");
                    Map<String,String> headers = new HashMap<>();
                    headers.put("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self' https://api.weather.gov https://api.open-meteo.com https://air-quality-api.open-meteo.com https://geocoding-api.open-meteo.com; frame-src 'none'; object-src 'none'; base-uri 'self'; form-action 'none'");
                    headers.put("X-Content-Type-Options","nosniff");
                    response.setResponseHeaders(headers);
                    return response;
                }
                if ("https".equals(url.getScheme()) && API_HOSTS.contains(url.getHost()) && !request.isForMainFrame()) return null;
                return denied(403,"External resources are not permitted");
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl();
                if(trusted(uri) && (uri.getPath().contains("/downloads/") || uri.getPath().contains("/vis-2/"))) { openExternal(uri.buildUpon().authority("dodgey512-blake.github.io").build()); return true; }
                if (trusted(uri) && request.isForMainFrame()) return false;
                if(request.isForMainFrame() && ("https".equals(uri.getScheme()) || "mailto".equals(uri.getScheme()))) openExternal(uri);
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                if(trusted(Uri.parse(url))) {
                    if(WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
                        view.evaluateJavascript(BRIDGE,null);
                        emit(json("type","ready","version","1.0.0","language",language));
                    }
                }
            }
            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                ((FrameLayout)view.getParent()).removeView(view);
                view.destroy();web=null;
                new AlertDialog.Builder(MainActivity.this).setTitle(text("重新打开天气","Reopen Weather"))
                    .setMessage(text("页面暂时中断，已保存的计划仍保留在此设备。","The page stopped. Saved plans remain on this device."))
                    .setPositiveButton(text("重新打开","Reopen"),(dialog,which)->recreate()).setNegativeButton(text("退出","Close"),(dialog,which)->finish()).setCancelable(false).show();
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if(!ORIGIN.equals(origin) && !(ORIGIN+"/").equals(origin)) { callback.invoke(origin,false,false); return; }
                geoCallback=callback; geoOrigin=origin;
                if(hasLocationPermission()) resolveGeolocation(true); else requestLocationPermission();
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if(filePicker!=null) filePicker.onReceiveValue(null);
                filePicker=callback;
                try { startActivityForResult(params.createIntent(),PICK_DOCUMENT); return true; }
                catch(Exception exception) { filePicker.onReceiveValue(null);filePicker=null;return false; }
            }
        });
        if(WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(web,"WeatherBridge",Collections.singleton(ORIGIN),(view,message,sourceOrigin,isMainFrame,replyProxy)->{
                if(!isMainFrame || !ORIGIN.equals(sourceOrigin.toString()) || !trusted(Uri.parse(view.getUrl()==null?"":view.getUrl()))) return;
                String data=message.getData();
                if(data==null || data.length()>12_000_000) return;
                try { handle(new JSONObject(data)); } catch(Exception exception) { error("bridge",text("操作未完成，请重试","The action could not be completed. Try again.")); }
            });
            if(WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) WebViewCompat.addDocumentStartJavaScript(web,BRIDGE,Collections.singleton(ORIGIN));
        }
        if(Build.VERSION.SDK_INT >= 33) getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0,this::goBack);
        if(savedInstanceState==null || web.restoreState(savedInstanceState)==null) web.loadUrl(START);
        root.requestApplyInsets();
    }

    private boolean trusted(Uri uri) { return "https".equals(uri.getScheme()) && "appassets.androidplatform.net".equals(uri.getHost()) && uri.getPort()==-1 && uri.getPath()!=null && uri.getPath().startsWith("/weather-v1/"); }
    private WebResourceResponse denied(int code,String message) { return new WebResourceResponse("text/plain","utf-8",code,message,Collections.emptyMap(),new ByteArrayInputStream(message.getBytes(StandardCharsets.UTF_8))); }
    private void openExternal(Uri uri) { try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); } catch(Exception exception) { error("link",text("没有可用于打开链接的应用","No app can open this link.")); } }
    private String text(String zh,String en) { return "en".equals(language)?en:zh; }
    private JSONObject json(Object... values) { JSONObject value=new JSONObject(); try{for(int i=0;i<values.length;i+=2)value.put(String.valueOf(values[i]),values[i+1]);}catch(Exception ignored){}return value; }
    private void emit(JSONObject value) { if(web==null)return;handler.post(()->{if(trusted(Uri.parse(web.getUrl()==null?"":web.getUrl())))web.evaluateJavascript("window.dispatchEvent(new CustomEvent('weather-native',{detail:"+value+"}));",null);}); }
    private void error(String operation,String message) { emit(json("type","error","operation",operation,"message",message)); }
    private void handle(JSONObject message) {
        switch(message.optString("method")) {
            case "requestNotifications": requestNotifications(); break;
            case "notify": showNotification(message.optString("title"),message.optString("body")); break;
            case "requestLocation": if(hasLocationPermission()) readLocation();else requestLocationPermission(); break;
            case "saveFile": saveFile(message.optString("name"),message.optString("mime"),message.optString("base64"));break;
            case "setLanguage":
                language="en".equals(message.optString("language"))?"en":"zh-CN";
                getPreferences(MODE_PRIVATE).edit().putString("language",language).apply();
                emit(json("type","language","language",language));break;
            default: error("bridge",text("不支持的操作","Unsupported action"));
        }
    }
    private void requestNotifications() {
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_PERMISSION);
        else emit(json("type","notifications","granted",getSystemService(NotificationManager.class).areNotificationsEnabled()));
    }
    private void showNotification(String title,String body) {
        NotificationManager manager=getSystemService(NotificationManager.class);
        if((Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)||!manager.areNotificationsEnabled()) { error("notify",text("请在设置中允许通知","Allow notifications in Settings first."));return; }
        if(title.trim().isEmpty()||body.trim().isEmpty())return;
        manager.createNotificationChannel(new NotificationChannel(CHANNEL,text("天气更新","Weather updates"),NotificationManager.IMPORTANCE_DEFAULT));
        PendingIntent intent=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification notification=new Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_weather_notification).setContentTitle(title.substring(0,Math.min(title.length(),100))).setContentText(body.substring(0,Math.min(body.length(),300))).setStyle(new Notification.BigTextStyle().bigText(body.substring(0,Math.min(body.length(),1000)))).setContentIntent(intent).setAutoCancel(true).build();
        manager.notify(1001,notification);emit(json("type","notification","delivered",true));
    }
    private boolean hasLocationPermission() { return checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED; }
    private void requestLocationPermission() { requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION},LOCATION_PERMISSION); }
    private void resolveGeolocation(boolean granted) { if(geoCallback!=null){geoCallback.invoke(geoOrigin,granted,false);geoCallback=null;geoOrigin=null;} }
    @SuppressWarnings("MissingPermission") private void readLocation() {
        if(requestInProgress)return;
        LocationManager manager=getSystemService(LocationManager.class);
        String provider=manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)?LocationManager.NETWORK_PROVIDER:LocationManager.GPS_PROVIDER;
        if(!manager.isProviderEnabled(provider)){error("location",text("请打开设备定位或手动搜索地点","Turn on device location or search for a place."));return;}
        requestInProgress=true;
        if(Build.VERSION.SDK_INT>=30) {
            locationCancellation=new CancellationSignal();
            manager.getCurrentLocation(provider,locationCancellation,getMainExecutor(),location->{requestInProgress=false;if(location!=null)emitLocation(location);else error("location",text("未能获取位置，请手动搜索","Location is unavailable. Search for a place."));});
            handler.postDelayed(()->{if(requestInProgress){requestInProgress=false;locationCancellation.cancel();error("location",text("定位超时，请手动搜索","Location timed out. Search for a place."));}},20000);
        } else {
            LocationListener listener=new LocationListener(){public void onLocationChanged(Location location){requestInProgress=false;manager.removeUpdates(this);emitLocation(location);}public void onStatusChanged(String p,int s,Bundle b){}public void onProviderEnabled(String p){}public void onProviderDisabled(String p){}};
            manager.requestSingleUpdate(provider,listener,Looper.getMainLooper());
            handler.postDelayed(()->{if(requestInProgress){requestInProgress=false;manager.removeUpdates(listener);error("location",text("定位超时，请手动搜索","Location timed out. Search for a place."));}},20000);
        }
    }
    private void emitLocation(Location location) { emit(json("type","location","latitude",location.getLatitude(),"longitude",location.getLongitude(),"accuracy",location.getAccuracy())); }
    private void saveFile(String name,String mime,String base64) {
        if(pendingFile!=null){error("saveFile",text("请先完成当前保存","Finish saving the current file first."));return;}
        if(base64.length()>10_000_000){error("saveFile",text("文件过大","File is too large."));return;}
        try {
            pendingFile=Base64.decode(base64,Base64.DEFAULT);
            pendingName=name.replaceAll("[^\\p{L}\\p{N}._ -]","_");
            if(pendingName.trim().isEmpty())pendingName="weather-export.json";
            if(!Arrays.asList("application/json","text/calendar","text/plain").contains(mime))mime="application/octet-stream";
            Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).putExtra(Intent.EXTRA_TITLE,pendingName);
            startActivityForResult(intent,SAVE_DOCUMENT);
        }catch(Exception exception){pendingFile=null;error("saveFile",text("无法打开文件保存窗口","Could not open the file picker."));}
    }
    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(code,permissions,results);
        if(code==NOTIFICATION_PERMISSION)emit(json("type","notifications","granted",Build.VERSION.SDK_INT<33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED));
        if(code==LOCATION_PERMISSION){boolean allowed=hasLocationPermission();if(geoCallback!=null)resolveGeolocation(allowed);else if(allowed)readLocation();else error("location",text("定位权限未开启，可以手动搜索地点","Location permission is off. Search for a place instead."));}
    }
    @Override protected void onActivityResult(int code,int resultCode,Intent data) {
        super.onActivityResult(code,resultCode,data);
        if(code==PICK_DOCUMENT && filePicker!=null){filePicker.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));filePicker=null;}
        if(code==SAVE_DOCUMENT && pendingFile!=null){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null){try(OutputStream stream=getContentResolver().openOutputStream(data.getData())){if(stream==null)throw new IllegalStateException();stream.write(pendingFile);emit(json("type","saved","name",pendingName));}catch(Exception exception){error("saveFile",text("保存失败，请重试","Save failed. Try again."));}}
            else emit(json("type","saveCancelled","name",pendingName));
            pendingFile=null;pendingName=null;
        }
    }
    private void goBack(){web.evaluateJavascript("typeof window.__weatherBack==='function' ? Boolean(window.__weatherBack()) : false", result->{if(!"true".equals(result)){if(web.canGoBack())web.goBack();else finish();}});}
    // API 33+ uses the registered OnBackInvokedCallback above. This override is for API 26–32.
    @SuppressLint("GestureBackNavigation") @Override public void onBackPressed(){goBack();}
    @Override protected void onSaveInstanceState(Bundle bundle){if(web!=null)web.saveState(bundle);super.onSaveInstanceState(bundle);}
    @Override protected void onResume(){super.onResume();if(web!=null){web.onResume();web.evaluateJavascript("window.dispatchEvent(new Event('weather-resume'))",null);}}
    @Override protected void onPause(){if(web!=null)web.onPause();super.onPause();}
    @Override protected void onDestroy(){if(locationCancellation!=null)locationCancellation.cancel();if(web!=null){web.stopLoading();web.destroy();web=null;}super.onDestroy();}
    WebView webViewForTest(){return web;}
}
